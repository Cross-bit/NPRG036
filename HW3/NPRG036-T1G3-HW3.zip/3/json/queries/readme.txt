query-1-1:
Vrátí všechny údaje ID Lessons, pokud se hodina vyskytuje v časovém slotu začínajícím později než 7:45:00 a ověří s kódem dané lesson, zda-li hodina má platný URL na zoom meeting.

query-4-1:
Najde všechny učitele s křesním jménem Jaroslav, jenž mají více než dvouleté zkušenosti a vyučují matematiku nebo angličtinu. Výstup obsahuje jméno učitele společně s lety jeho zkušeností.

query-5-1:
Najde mezi rozvrhy pro letošní a následující akademické roky všechna jména studentů, jenž dochází do čtvrté a vyšší třídy, kde kódové označení třídy odpovídá 'C'.

query-5-2:
Pro třídu 5. ročníku a výše s označením B vypíše třídní identifikátor, pokud je součástí této třídy student Jiří Klimošek.
